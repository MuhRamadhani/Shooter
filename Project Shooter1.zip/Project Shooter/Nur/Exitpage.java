import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Exitpage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Exitpage extends World
{

    /**
     * Constructor for objects of class Exitpage.
     * 
     */
    public Exitpage()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1250, 720, 1); 
        prepare();
    }
    private void prepare()
    {
        Rusure rusure = new Rusure();
        addObject(rusure, 625, 260);
        rusure.setLocation(625,260);
        
        Yes yes = new Yes();
        addObject(yes, 435, 480);
        yes.setLocation(435,480);
        
        No no = new No();
        addObject(no, 820, 480);
        no.setLocation(820,480);
    }
}
