import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bg here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bg extends World
{

    /**
     * Constructor for objects of class Bg.
     * 
     */
    public Bg()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1250, 720, 1);
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Counter counter = new Counter();
        addObject(counter,1135,683);
        counter.setLocation(1135,683);
        
        Home home = new Home();
        addObject(home,1200,27);
        home.setLocation(1200,27);
    }

    public void act()
    {
        if(Greenfoot.getRandomNumber(400) < 5)
        {
            addObject(new Target(), Greenfoot.getRandomNumber(1250),500);
            addObject(new Tjangan(), Greenfoot.getRandomNumber(1250),500);
        }
    }
}
