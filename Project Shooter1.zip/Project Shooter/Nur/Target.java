import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Target here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Target extends Actor
{
    /**
     * Act - do whatever the Target wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    World w;
    public void act()
    {
        World w = getWorld();
        setLocation(getX(), getY()-1);
        if(isAtEdge())
        {
            w.removeObject(this);
            Counter.add(-2);
        }
        if (Greenfoot.mouseClicked(this)) 
        {
            w.removeObject(this);
            Counter.add(2);
        }
        if (Counter.value==0){
            Greenfoot.delay(1);
            Greenfoot.setWorld(new Gameover());
        }
        if (Counter.value==40){
            Greenfoot.delay(1);
            Greenfoot.setWorld(new Gamewin());
        }
    }
}
