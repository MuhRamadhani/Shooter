import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Homescreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Homescreen extends World
{

    /**
     * Constructor for objects of class Homescreen.
     * 
     */
    public Homescreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1250, 720, 1);
        prepare();
    }
    
    private void prepare()
    {
        Judul judul = new Judul();
        addObject(judul, 625, 180);
        judul.setLocation(625,180);
        
        Play play = new Play();
        addObject(play,625,360);
        play.setLocation(625,360);
        
        Help help = new Help();
        addObject(help,625,440);
        help.setLocation(625,440);
        
        Setting setting = new Setting();
        addObject(setting,625,520);
        setting.setLocation(625,520);
        
        Exit exit = new Exit();
        addObject(exit,625,600);
        exit.setLocation(625,600);
    }
}
