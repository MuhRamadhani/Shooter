import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Back here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Back extends Tombol
{
    /**
     * Act - do whatever the Back wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    boolean mouseOver = false;
    public void act()
    {
        if(Greenfoot.mousePressed(this)){
            Greenfoot.delay(1);
            Greenfoot.setWorld(new Homescreen());
        }
        
        if (!mouseOver && Greenfoot.mouseMoved(this))  
        {  
            setImage("HomeM.png");  
            mouseOver = true;
        }
        if (mouseOver && Greenfoot.mouseMoved(null) && ! Greenfoot.mouseMoved(this))  
        {  
            setImage("HomeK.png");
            mouseOver = false;
        } 
    }
}
