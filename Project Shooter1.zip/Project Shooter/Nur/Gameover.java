import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gameover here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gameover extends World
{

    /**
     * Constructor for objects of class Gameover.
     * 
     */
    public Gameover()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1250, 720, 1);
        prepare();
    }
    private void prepare()
    {
        Over over = new Over();
        addObject(over, 625, 240);
        over.setLocation(625,240);
        
        Back back = new Back();
        addObject(back,625,520);
        back.setLocation(625,520);
        
        Lagi lagi = new Lagi();
        addObject(lagi,625,440);
        lagi.setLocation(625,440);
        
        Exit exit = new Exit();
        addObject(exit,625,600);
        exit.setLocation(625,600);
    }
}
